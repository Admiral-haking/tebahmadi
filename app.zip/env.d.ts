export {};

declare global {
  namespace NodeJS {
    interface ProcessEnv {
      MONGO_URI: string;
      NODE_ENV?: 'development' | 'production' | 'test';
      APP_BASE_URL?: string;
      JWT_SECRET: string;
      JWT_TTL_SECONDS?: string;
      ZARINPAL_MERCHANT_ID: string;
      ZARINPAL_SANDBOX?: 'true' | 'false';
      PAYMENT_CALLBACK_PATH?: string;
      GHASEDAK_API_KEY: string;
    }
  }
}
