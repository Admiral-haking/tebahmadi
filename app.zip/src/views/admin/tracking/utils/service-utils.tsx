import { ITRackServiceIdType } from "../type";

import digikala from "@/layout/assets/digikala.jpeg";
import snapp from "@/layout/assets/snapp.jpg";
import basalaam from "@/layout/assets/basalaam.png";
import { Box } from "@mui/material";
import Image from "next/image";

export const getTrackServiceLabel = (serviceId: ITRackServiceIdType | string) => {
    switch (serviceId) {
        case "dgk": return "دیجی کالا"
        case "basalaam": return "باسلام"
        case "snapp": return "اسنپ شاپ"
        case "website": return "وب سایت"
        default: return "دستی"
    }
}
export const TrackServiceIcon = ({ serviceId }: { serviceId: ITRackServiceIdType | string }) => {
    switch (serviceId) {
        case "dgk": return <Box
            component={Image}
            src={digikala}
            width={18}
            height={18}
            alt="digikala"
            sx={{ borderRadius: .6 }}
        />
        case "basalaam": return <Box
            component={Image}
            src={basalaam}
            width={18}
            height={18}
            alt="basalaam"
            sx={{ borderRadius: .6 }}
        />
        case "snapp": return <Box
            component={Image}
            src={snapp}
            width={18}
            height={18}
            alt="snapp"
            sx={{ borderRadius: .6 }}
        />
        case "website":
        default: return <svg xmlns="http://www.w3.org/2000/svg" width={18} height={18} viewBox="0 0 24 24" >
            <path fill="currentColor" fillRule="evenodd" d="M12.75 2a.75.75 0 0 0-1.5 0v1.5H6.704c-.658 0-.986 0-1.288.098a2 2 0 0 0-.383.17c-.274.16-.494.404-.933.894c-.85.947-1.276 1.42-1.379 1.974a2 2 0 0 0 0 .728c.103.553.528 1.027 1.379 1.974c.44.49.659.734.933.893q.183.105.383.17c.302.099.63.099 1.288.099h4.546v2H6.5c-1.404 0-2.107 0-2.611.337a2 2 0 0 0-.552.552C3 13.893 3 14.596 3 16s0 2.107.337 2.611a2 2 0 0 0 .552.552c.504.337 1.207.337 2.611.337h4.75v1.75H10a.75.75 0 0 0 0 1.5h4a.75.75 0 0 0 0-1.5h-1.25V19.5h4.546c.658 0 .986 0 1.288-.098q.2-.066.383-.17c.274-.16.494-.404.933-.894c.85-.947 1.276-1.42 1.379-1.974a2 2 0 0 0 0-.728c-.103-.553-.528-1.027-1.379-1.974c-.44-.49-.659-.734-.933-.893a2 2 0 0 0-.383-.17c-.302-.099-.63-.099-1.288-.099H12.75v-2h4.75c1.404 0 2.107 0 2.611-.337a2 2 0 0 0 .552-.552C21 9.107 21 8.404 21 7s0-2.107-.337-2.611a2 2 0 0 0-.552-.552C19.607 3.5 18.904 3.5 17.5 3.5h-4.75z" clipRule="evenodd" > </path>
        </svg>
    }
}