import { loadSiteConfig } from '@/lib/cache';

export interface SmsTemplateBinding {
  template: string;
  variables: string[];
}

type SmsTemplateKind =
  | 'loginCode'
  | 'orderConfirmation'
  | 'paymentReceipt'
  | 'shipmentTracking'
  | 'reviewRequest';

const DEFAULT_LOGIN_TEMPLATE: SmsTemplateBinding = {
  template: 'Otp',
  variables: ['code'],
};

const GHASEDAK_ENDPOINT = 'https://gateway.ghasedak.me/rest/api/v1/WebService/SendOtpWithParams';

function getApiKey(): string {
  const key = process.env.GHASEDAK_API_KEY;
  if (!key) {
    throw new Error('GHASEDAK_API_KEY env variable is not configured');
  }
  return key;
}

function buildPayload(
  template: string,
  receptor: string,
  params: Record<string, string>,
) {
  return {
    receptors: [
      {
        mobile: receptor,
      },
    ],
    templateName: template,
    ...params,
  };
}

function mapVariablesToParams(binding: SmsTemplateBinding, data: Record<string, unknown>): Record<string, string> {
  const params: Record<string, string> = {};
  binding.variables.forEach((key, index) => {
    const value = data[key];
    params[`param${index + 1}`] = value === undefined || value === null ? '' : String(value);
    params[`param${index + 1}`] = params[`param${index + 1}`].replaceAll(" ", "_")
  });
  return params;
}

async function postGhasedak(payload: Record<string, unknown>): Promise<void> {
  const response = await fetch(GHASEDAK_ENDPOINT, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'cache-control': 'no-cache',
      apikey: getApiKey(),
    },
    body: JSON.stringify(payload),
  });

  if (!response.ok) {
    const message = await response.text().catch(() => '');
    const details = message.trim() || response.statusText || 'Unknown error';
    console.log(`Ghasedak send failed (HTTP ${response.status}): ${details}`);
  }
}

async function resolveTemplate(kind: SmsTemplateKind): Promise<SmsTemplateBinding | null> {
  const config = await loadSiteConfig();
  const binding = config?.smsTemplates?.[kind];
  if (!binding?.template) {
    return null;
  }
  return {
    template: binding.template,
    variables: binding.variables ?? [],
  } satisfies SmsTemplateBinding;
}

export async function sendTemplateSms(
  binding: SmsTemplateBinding,
  receptor: string,
  data: Record<string, unknown>,
): Promise<void> {
  if (!binding?.template) {
    throw new Error('SMS template is not configured');
  }
  const params = mapVariablesToParams(binding, data);
  const payload = buildPayload(binding.template, receptor, params);
  await postGhasedak(payload);
}

export async function sendLoginCode(
  receptor: string,
  code: string,
): Promise<void> {
  const binding = await resolveTemplate('loginCode');
  const effectiveBinding: SmsTemplateBinding = binding
    ? {
      template: binding.template,
      variables: binding.variables?.length ? binding.variables : DEFAULT_LOGIN_TEMPLATE.variables,
    }
    : DEFAULT_LOGIN_TEMPLATE;

  const variables = effectiveBinding.variables.length ? effectiveBinding.variables : DEFAULT_LOGIN_TEMPLATE.variables;

  const data: Record<string, unknown> = { code };
  variables.forEach((variable, index) => {
    if (typeof data[variable] === 'undefined') {
      data[variable] = index === 0 ? code : '';
    }
  });

  await sendTemplateSms(effectiveBinding, receptor, data);
}

export async function sendOrderConfirmationSms(
  receptor: string,
  data: Record<string, unknown>,
): Promise<void> {
  const binding = await resolveTemplate('orderConfirmation');
  if (!binding) {
    return;
  }
  await sendTemplateSms(binding, receptor, data);
}

export async function sendPaymentReceiptSms(
  receptor: string,
  data: Record<string, unknown>,
): Promise<void> {
  const binding = await resolveTemplate('paymentReceipt');
  if (!binding) {
    return;
  }
  await sendTemplateSms(binding, receptor, data);
}

export async function sendShipmentTrackingSms(
  receptor: string,
  data: Record<string, unknown>,
): Promise<void> {
  const binding = await resolveTemplate('shipmentTracking');
  if (!binding) {
    return;
  }
  await sendTemplateSms(binding, receptor, data);
}

export async function sendReviewRequestSms(
  receptor: string,
  data: Record<string, unknown>,
): Promise<void> {
  const binding = await resolveTemplate('reviewRequest');
  if (!binding) {
    return;
  }
  await sendTemplateSms(binding, receptor, data);
}
